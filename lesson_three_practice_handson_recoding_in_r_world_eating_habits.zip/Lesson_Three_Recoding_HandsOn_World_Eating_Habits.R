# Import packages
library(tidyr)
library(dplyr)

# Import Data Sets and View

# Creating a copy of the original data set and View the list of values

Eating_Habits2 <- Eating_Habits
str(Eating_Habits2)

# Recode Activity into a new variable called JunkFood. 
# Anything that you would consider junk food, recode as a 1. 
# Everything else should be recoded as a zero.
# Recode Sex from text to numbers in the same variable

# In order to record into a new variable in R, create a new, but empty variable. 
# Assigning values as NA is how you'll do that:

Eating_Habits2$JunkFood <- NA

# Fill new column in! Specify the name of the dataset 
# and new variable first, then in square brackets, place the old variable 
# name and the old variable values. After the arrow, you will place the new 
# variable value.

Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating fruit'] <- 0
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating raw vegetables'] <- 0
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating candy, chocolate bars'] <- 1
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating potato chips, crisps'] <- 1
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating french fries'] <- 1
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating hamburgers, hot dogs or sausages'] <- 1
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating peanuts'] <- 0
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating whole wheat or rye bread'] <- 0
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Drinking soft drinks, cola or other drinks with sugar'] <- 1
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Drinking coffee'] <- 0
Eating_Habits2$JunkFood[Eating_Habits2$Activity=='Eating Fruit'] <- 0
Eating_Habits2$Sex[Eating_Habits2$Sex=='Male'] <- 0
Eating_Habits2$Sex[Eating_Habits2$Sex=='Female'] <- 1

# Not sure I got the last part right -  recoding sex from text to numbers
# Will have to revisit. 